千年纪事的历史地图源文件

本存档提供按 GPL-3.0 发布的 Historical Basemaps 数据层的原始 GeoJSON
以及本网站的投影、裁剪、渲染脚本。源数据来自
https://github.com/aourednik/historical-basemaps
本存档所附 COPYING 是该项目的 GPL-3.0 许可。

网站从各年度的 GeoJSON 选取若干政权，以同一个经纬度图框裁剪、轻度简化后
渲染成 SVG。图框为东经 68 至 142 度、北纬 13 至 56 度，图幅为
888 × 516。历史政区、羁縻政区与实际控制区按每张地图的图注区分。

其余资料另行遵循其数据许可。Natural Earth 海岸线数据为公有领域，
原始数据文件随存档提供。Hartwell 与 CHGIS 原始文件可从哈佛数据档案馆
下载。Hartwell 的 legacy README 和 CHGIS 许可说明规定非商业学术用途，
对应资料用于学习展示。

Hartwell China Historical GIS
https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/29302
https://dataverse.harvard.edu/api/access/datafile/2542563

CHGIS 1820 年省级政区
https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/2K4FHX
https://dataverse.harvard.edu/api/access/datafile/2966705

CHGIS 1911 年省级政区
https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/HHVVHX
https://dataverse.harvard.edu/api/access/datafile/2966688

930 年州府和 1200 年金、西夏使用开源 china-history-map 网站发布的
CHGIS 和 Hartwell 地理数据转换结果。
https://github.com/pessimistcamellia/china-history-map/blob/main/DEVLOG.md

复现时把 work 目录放到项目同级，补齐脚本引用的资料文件，再安装
pyshp、pyproj、shapely。脚本把地图输出到
work/china-history-atlas/dist/images，所需图幅和政权名称见脚本。
