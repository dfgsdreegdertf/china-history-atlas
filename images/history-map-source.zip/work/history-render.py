from pathlib import Path
import struct
import sys
import zlib
import json
from zipfile import ZipFile
from io import BytesIO
from html import escape

work = Path(__file__).parent
sys.path.insert(0, str(work / "history-python"))
import shapefile
from pyproj import CRS, Transformer
from shapely import make_valid, union_all
from shapely.geometry import box, shape, mapping, Polygon
from shapely.ops import transform

dist = work / "china-history-atlas" / "dist"
frame = box(68, 13, 142, 56)
hartwell = "https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/29302"
chgis = "https://gis.harvard.edu/china-historical-gis"
archive = "https://github.com/aourednik/historical-basemaps/blob/master/geojson/"
conversion = "https://github.com/pessimistcamellia/china-history-map/blob/main/DEVLOG.md"
natural_earth = "https://www.naturalearthdata.com/downloads/110m-physical-vectors/110m-land/"
cc0 = "https://creativecommons.org/publicdomain/zero/1.0/"
gpl = "https://github.com/aourednik/historical-basemaps/blob/master/LICENSE"


def members(path):
    data = path.read_bytes()
    i = 0
    while data[i : i + 4] == b"PK\x03\x04":
        _, flag, method, _, _, _, size, _, nlen, elen = struct.unpack_from("<5H3I2H", data, i + 4)
        name = data[i + 30 : i + 30 + nlen].decode("utf-8")
        start = i + 30 + nlen + elen
        i = start + size
        if i > len(data) or flag & 8:
            break
        yield name, data[start:i], method


def load_partial_zip(path, suffixes):
    return {
        Path(name).name: zlib.decompress(data, -15) if method == 8 else data
        for name, data, method in members(path)
        if name.endswith(suffixes)
    }


def projected_shapefile(data, stem, encoding):
    reader = shapefile.Reader(
        shp=BytesIO(data[stem + ".shp"]),
        dbf=BytesIO(data[stem + ".dbf"]),
        encoding=encoding,
        encodingErrors="replace",
    )
    converter = Transformer.from_crs(
        CRS.from_wkt(data[stem + ".prj"].decode()), "EPSG:4326", always_xy=True
    )
    return [(sr.record.as_dict(), transform(converter.transform, shape(sr.shape.__geo_interface__))) for sr in reader.iterShapeRecords()]


def layer(features, selector=lambda p: True):
    return [
        shape(f["geometry"])
        for f in features
        if f["geometry"] and selector(f["properties"])
    ]


def world(year):
    path = work / f"history-base-world_{year}.geojson"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))["features"]
    embedded = compiled[f"world_{year}"]["features"]
    return [
        {**f, "properties": {"NAME": f["properties"].get("name_en")}}
        for f in embedded
    ]


def polity(year, *names):
    return layer(world(year), lambda p: p.get("NAME") in names)


def clipped(paths):
    return [
        make_valid(path).intersection(frame).simplify(.06, preserve_topology=True)
        for path in paths if not path.is_empty and path.intersects(frame)
    ]


def xy(lon, lat):
    return (lon - 68) * 12, (56 - lat) * 12


def ring_path(coords):
    return "M" + " ".join(f"{x:.1f},{y:.1f}" for x, y in (xy(*p[:2]) for p in coords)) + "Z"


def shape_path(geom):
    if geom.is_empty:
        return ""
    if isinstance(geom, Polygon):
        return ring_path(geom.exterior.coords) + "".join(ring_path(ring.coords) for ring in geom.interiors)
    return "".join(shape_path(g) for g in getattr(geom, "geoms", []))


def draw_geometry(paths, fill, stroke, width=1.0, dashed=False, merge=False):
    geoms = clipped(paths)
    if merge:
        geoms = [union_all(geoms)]
    content = "".join(shape_path(g) for g in geoms)
    dash = ' stroke-dasharray="4 2"' if dashed else ""
    return (
        f'<path d="{content}" fill="{fill}" fill-rule="evenodd" stroke="{stroke}" '
        f'stroke-width="{width}" stroke-linejoin="round"{dash}/>'
    ) if content else ""


with ZipFile(work / "world-land.zip") as z:
    shp = next(n for n in z.namelist() if n.endswith(".shp"))
    base_shapes = [shape(s.__geo_interface__) for s in shapefile.Reader(shp=BytesIO(z.read(shp))).shapes()]

base = draw_geometry(base_shapes, "#243a42", "#5a7780", .75)
grid = "".join(f"M{xy(lon,56)[0]} 0V516" for lon in range(70, 142, 10))
grid += "".join(f"M0 {xy(68,lat)[1]}H888" for lat in range(20, 56, 10))

compiled = json.loads((work / "history-render-input.json").read_text(encoding="utf-8"))
tang_stem = "v5_0741_chin_chn_0741_c"
tang_records = projected_shapefile(
    load_partial_zip(work / "history-hartwell-v5.zip", (tang_stem + ".shp", tang_stem + ".dbf", tang_stem + ".prj")),
    tang_stem, "big5"
)
tang = [g for props, g in tang_records if props["H_ADMIN_TY"] in {"Xian", "Zhou", "Jun", "Cheng"}]
tang_border = [
    g for props, g in tang_records
    if props["H_ADMIN_TY"] in {"Jimizhou", "Jimi zhou", "Dudufu", "Daduhufu", "Duhufu", "Duhu fu", "Suoling"}
]

palette = {
    "gold": ("#8c6338", "#f4c681"),
    "red": ("#854a4b", "#e9a19a"),
    "green": ("#426952", "#a2c6a9"),
    "blue": ("#416883", "#9cc7df"),
    "purple": ("#5f5177", "#c8b5df"),
}
editions = []


def field(paths, name, longitude, latitude, color, *, dashed=False, merge=True):
    return (paths, name, longitude, latitude, color, dashed, merge)


def render(year, start, title, credit, credit_title, note, fields, *, end=None, rights=cc0):
    descriptions = "; ".join(name for _, name, *_ in fields if name)
    chunks = [
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 888 516">',
        f'<title>{escape(title)}</title>',
        f'<desc>{escape(note)} {escape(descriptions)}。底图 Natural Earth。数据 {escape(credit)}。许可 {escape(rights)}。</desc>',
        '<rect width="888" height="516" fill="#182a33"/>',
        base,
        f'<path d="{grid}" fill="none" stroke="#52686e" stroke-opacity=".4" stroke-width=".7"/>',
    ]
    labels = []
    for paths, name, longitude, latitude, color, dashed, merge in fields:
        fill, stroke = palette[color]
        chunks.append(draw_geometry(paths, fill, stroke, .95, dashed, merge))
        if name:
            x, y = xy(longitude, latitude)
            labels.append(
                f'<text x="{x}" y="{y}" text-anchor="middle" '
                f'fill="{stroke}" font-size="23" font-weight="700" '
                f'paint-order="stroke" stroke="#1b2c32" stroke-width="3.5">{escape(name)}</text>'
            )
    chunks.extend(['<g font-family="PingFang SC, Microsoft YaHei, sans-serif">', *labels, "</g>", "</svg>"])
    filename = f"images/history-{year}.svg"
    (dist / filename).write_text("\n".join(chunks) + "\n", encoding="utf-8")
    entry = dict(
        year=year, title=title, url=filename, credit=credit, creditTitle=credit_title,
        note=note, width=888, height=516, license=rights,
    )
    entry["from"] = start
    if end is not None:
        entry["to"] = end
    if rights == gpl:
        entry["dataSource"] = "images/history-map-source.zip"
    editions.append(entry)


render(741, 618, "唐 · 741 年政区", hartwell, "哈佛大学 Hartwell 历史地理数据",
       "以741年可考政区为参照。金色为州县等常设政区，蓝色虚线为部分都护、都督及羁縻政区。", [
    field(tang, "唐州县", 112.3, 32.5, "gold"),
    field(tang_border, "边地管辖区", 88.3, 40.8, "blue", dashed=True),
])
render(930, 907, "五代十国 · 930 年州府", conversion, "CHGIS 时间序列 · 930 年州府",
       "显示历史 GIS 资料所载州府范围。描边划分州府，图层缺项留空；各政权实际控制范围另见史料。", [
    field(layer(compiled["five_d"]["features"]), "州府记录", 115.8, 30.0, "blue", merge=False),
])
render(1100, 960, "北宋、辽、西夏 · 1100 年", archive + "world_1100.geojson", "Historical Basemaps · 1100 年",
       "描绘北宋、辽与西夏的并立格局，界线为资料重建的约略范围。", [
    field(polity(1100, "Song Empire"), "北宋", 113.5, 31.0, "gold"),
    field(polity(1100, "Liao"), "辽", 121.5, 44.0, "red", dashed=True),
    field(polity(1100, "Xixia"), "西夏", 99.3, 39.4, "green", dashed=True),
], rights=gpl)
render(1200, 1127, "南宋、金、西夏 · 1200 年", hartwell, "Hartwell · 1200 年政区",
       "金、西夏取自 Hartwell 的1200年分政权政区。南宋外廓取自 Historical Basemaps 同年断面。", [
    field(polity(1200, "Song Empire"), "南宋", 113.6, 27.0, "gold"),
    field(layer(compiled["jin_dy"]["features"]), "金", 118.2, 40.2, "red", dashed=True),
    field(layer(compiled["xixia_1200"]["features"]), "西夏", 102.8, 39.2, "green", dashed=True),
], rights=gpl)
render(1279, 1271, "元 · 1279 年", archive + "world_1279.geojson", "Historical Basemaps · 1279 年",
       "1279年断面描绘元朝核心政治地理。西北及高原各地管辖方式和范围因地而异。", [
    field(polity(1279, "Great Khanate"), "元", 112.8, 42.0, "gold", dashed=True),
], rights=gpl)
render(1492, 1368, "明 · 1492 年", archive + "world_1492.geojson", "Historical Basemaps · 1492 年",
       "1492年的明朝重建范围，周边及部分羁縻或卫所关系从略。", [
    field(polity(1492, "Ming Empire"), "明", 113.3, 31.2, "gold"),
], rights=gpl)
render(1715, 1644, "清 · 1715 年", archive + "world_1715.geojson", "Historical Basemaps · 1715 年",
       "以康熙五十四年断面参照清前期。边地界线为重建示意。", [
    field(polity(1715, "Manchu Empire"), "清", 112.5, 37.3, "gold", dashed=True),
], rights=gpl)


def qing_provinces(year):
    with ZipFile(work / f"history-chgis-{year}-province.zip") as z:
        paths = {Path(name).name: z.read(name) for name in z.namelist() if name.endswith((".shp", ".dbf", ".prj"))}
    stem = next(n[:-4] for n in paths if n.endswith(".shp"))
    return [g for _, g in projected_shapefile(paths, stem, "gbk" if year == 1820 else "utf-8")]


render(1820, 1759, "清 · 1820 年政区", "https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/2K4FHX",
       "哈佛与复旦 CHGIS · 1820 年", "嘉庆二十五年省级政区断面，图中线条按历史地理数据库重建。", [
    field(qing_provinces(1820), "清", 111.0, 35.0, "gold", merge=False),
])
render(1878, 1860, "晚清 · 1878 年", archive + "world_1878.geojson", "Historical Basemaps · 1878 年",
       "晚清政治范围的约略断面，用于观察19世纪中后期变化。", [
    field(polity(1878, "Manchu Empire", "Taiwan"), "清", 111.0, 35.0, "gold", dashed=True),
], rights=gpl)
render(1911, 1895, "晚清 · 1911 年政区", "https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/HHVVHX",
       "哈佛与复旦 CHGIS · 1911 年", "宣统三年省级政区断面，适合与1820年断面对照。", [
    field(qing_provinces(1911), "清", 111.0, 35.0, "gold", merge=False),
])
render(1920, 1912, "民国初期 · 1920 年", archive + "world_1920.geojson", "Historical Basemaps · 1920 年",
       "以资料所示实际控制与地方势力为线索。虚线表示概略分区，法定疆界和外交主张另见史料。", [
    field(polity(1920, "Chinese Warlords"), "民国地方势力", 111.0, 33.5, "gold", dashed=True),
    field(polity(1920, "Manchuria"), "东北地区", 125.4, 45.5, "blue", dashed=True),
    field(polity(1920, "Xinjiang"), "新疆地方政权", 85.8, 42.8, "green", dashed=True),
], rights=gpl)
render(1938, 1937, "抗战时期 · 1938 年局势", archive + "world_1938.geojson", "Historical Basemaps · 1938 年",
       "资料所示主要控制区示意，东北及朝鲜半岛为日方控制区。华北等地控制线变动频繁。", [
    field(polity(1938, "Chinese warlords"), "中国主要控制区", 111.4, 32.7, "gold", dashed=True),
    field(polity(1938, "Xinjiang"), "新疆地方政权", 86.8, 42.8, "green", dashed=True),
    field(polity(1938, "Empire of Japan"), "日方控制区", 126.0, 46.8, "red", dashed=True),
], end=1944, rights=gpl)
render(1945, 1945, "抗战结束前后 · 1945 年局势", archive + "world_1945.geojson", "Historical Basemaps · 1945 年",
       "战争结束前后地区控制快速变化。图中主要分区保留资料所示约略范围，供比较。", [
    field(polity(1945, "China"), "中国", 112.7, 32.2, "gold", dashed=True),
    field(polity(1945, "Manchuria"), "东北地区", 125.8, 45.4, "blue", dashed=True),
    field(polity(1945, "Xinjiang"), "新疆地方政权", 86.8, 42.8, "green", dashed=True),
], end=1948, rights=gpl)

for edition in editions:
    assert (dist / edition["url"]).stat().st_size > 1500

(dist / "historical-maps.js").write_text(
    "// Historical reference editions. Coordinates use the same equirectangular grid.\n"
    + "const historicalMaps = "
    + json.dumps(editions, ensure_ascii=False, indent=2)
    + ";\n",
    encoding="utf-8",
)
print("Historical editions:", ", ".join(str(e["year"]) for e in editions))
